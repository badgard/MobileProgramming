package deu.cpt.p20173057;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class view_memo extends AppCompatActivity {
    private FirebaseUser user;
    private FirebaseDatabase db;
    private DatabaseReference Databaseref;
    private ListView listview;
    private MemoAdapter memoAdapter;
    private ArrayList<Memo> arrayList = new ArrayList<>();
    private long backTime = 0;
    View dialogview;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.itemNew){
            Intent intent = new Intent(getApplicationContext(), new_memo.class);
            startActivity(intent);
        }
        else if(item.getItemId() == R.id.itemInfo){
            dialogview = (View) View.inflate(view_memo.this, R.layout.dialog, null);
            AlertDialog.Builder dlg = new AlertDialog.Builder(view_memo.this);
            dlg.setTitle("개발자 정보");
            dlg.setMessage("동의대 컴퓨터공학과 문준석\nemfkrh0147@gmail.com");
            dlg.setView(dialogview);
            dlg.setPositiveButton("확인", null);
            dlg.show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_memo);

        user = FirebaseAuth.getInstance().getCurrentUser();
        db = FirebaseDatabase.getInstance();
        Databaseref = db.getReference("memo20173057/User/" + user.getUid());
        String id = user.getEmail();
        setTitle(id + "의 메모");

        Button btnSearch = (Button) findViewById(R.id.btnSearch);
        EditText edtSearch = (EditText) findViewById(R.id.edtSearch);
        listview = (ListView) findViewById(R.id.lv);
        memoAdapter = new MemoAdapter(arrayList, getApplicationContext());

       Databaseref.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               arrayList.clear();

               for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                   Memo memo = new Memo();
                   memo.setTitle(dataSnapshot.child("title").getValue(String.class));
                   memo.setDate(dataSnapshot.child("date").getValue(String.class));
                   arrayList.add(memo);
                   memo.setDetail(dataSnapshot.child("detail").getValue(String.class));
                   memo.setMod_Date(dataSnapshot.child("mod_date").getValue(String.class));
                   memo.setId(dataSnapshot.child(user.getUid()).getValue(String.class));
               }
               listview.setAdapter(memoAdapter);
           }

           @Override
           public void onCancelled(@NonNull DatabaseError error) {
           }
       });

       btnSearch.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

           }
       });

       listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               String date = arrayList.get(i).getDate();
               String mod_date = arrayList.get(i).getMod_Date();
               String title = arrayList.get(i).getTitle();
               String detail = arrayList.get(i).getDetail();
               String id = arrayList.get(i).getId();

               Intent intent = new Intent(getApplicationContext(), query_memo.class);
               intent.putExtra("pos", i);
               intent.putExtra("date", date);
               intent.putExtra("mod_date", mod_date);
               intent.putExtra("title", title);
               intent.putExtra("detail", detail);
               intent.putExtra("id", id);
               startActivity(intent);
           }
       });
    }


}