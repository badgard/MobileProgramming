package deu.cpt.p20173057;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class new_memo extends AppCompatActivity {
    private FirebaseAuth Firebaseauth;
    private DatabaseReference Databaseref;
    private FirebaseDatabase db;
    private FirebaseUser user;
    long mNow;
    Date mDate;
    //SimpleDateFormat 클래스로 날짜를 문자열 포맷으로저장
    SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM--dd hh:mm:ss");
    private long backTime = 0;
    View dialogview;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_memo);
        setTitle("새 메모 작성");

        Firebaseauth = FirebaseAuth.getInstance();
        user = Firebaseauth.getCurrentUser();
        db = FirebaseDatabase.getInstance();

        Button btnSave = (Button) findViewById(R.id.btnSave);
        Button btnClose = (Button) findViewById(R.id.btnClose);
        EditText edtNewTitle = (EditText) findViewById(R.id.edtNewTitle);
        EditText edtNewDetail = (EditText) findViewById(R.id.edtNewDetail);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNewTitle.getText().toString().trim().isEmpty()){
                    Toast.makeText(new_memo.this, "메모의 '제목'란이 비워졌습니다.", Toast.LENGTH_SHORT).show();
                }
                else{
                    mNow = System.currentTimeMillis();
                    mDate = new Date(mNow);
                    Memo memo = new Memo();

                    memo.setTitle(edtNewTitle.getText().toString());
                    memo.setDetail(edtNewDetail.getText().toString());
                    memo.setDate(getTime());
                    memo.setMod_Date(null);

                    Databaseref = db.getReference("memo20173057").child("User").child(user.getUid()).push();
                    Databaseref.setValue(memo);
                    Intent intent = new Intent(new_memo.this, view_memo.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogview = (View) View.inflate(new_memo.this, R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(new_memo.this);
                dlg.setMessage("현재 작성하는 메모를 취소하시겠습니까?");
                dlg.setView(dialogview);
                dlg.setNegativeButton("취소", null);
                //확인 클릭 메소드
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });
                dlg.show();
            }
        });
    }
    private String getTime(){
        mNow = System.currentTimeMillis();
        mDate = new Date(mNow);

        return mFormat.format(mDate);
    }
}
