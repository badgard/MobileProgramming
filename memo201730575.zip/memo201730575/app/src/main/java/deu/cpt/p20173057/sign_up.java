package deu.cpt.p20173057;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class sign_up extends AppCompatActivity {
    private FirebaseAuth Firebaseauth;
    private DatabaseReference Databaseref;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        setTitle("회원가입");

        Firebaseauth = FirebaseAuth.getInstance();
        Databaseref = FirebaseDatabase.getInstance().getReference("memo20173057");

        EditText edtSignId = findViewById(R.id.edtSignId);
        EditText edtSIgnPw = findViewById(R.id.edtSignPw);
        Button btnSign_Sign_Up = findViewById(R.id.btnSign_SignUp);

        btnSign_Sign_Up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String SId = edtSignId.getText().toString();
                String SPw = edtSIgnPw.getText().toString();

                Firebaseauth.createUserWithEmailAndPassword(SId, SPw).addOnCompleteListener
                        (sign_up.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            FirebaseUser user = Firebaseauth.getCurrentUser();
                            User account = new User();
                            account.setIdToken(user.getUid());
                            account.setId(user.getEmail());
                            account.setPw(SPw);

                            Databaseref.child("User").child(user.getUid()).setValue(account);
                            Toast.makeText(sign_up.this, "회원가입에 성공하셨습니다", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(sign_up.this, "회원가입에 실패하셨습니다", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}
