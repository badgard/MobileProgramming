package deu.cpt.p20173057;

import com.google.firebase.database.Exclude;

public class Memo {
    @Exclude
    private String id;
    private String Title;
    private String Detail;
    private String Date;
    private String Mod_Date;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDetail() {
        return Detail;
    }

    public void setDetail(String detail) {
        Detail = detail;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getMod_Date() {
        return Mod_Date;
    }

    public void setMod_Date(String mod_Date) {
        Mod_Date = mod_Date;
    }
}
