package deu.cpt.p20173057;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth Firebaseauth;
    private DatabaseReference Databaseref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("개인 메모 기록 서비스");

        Firebaseauth = FirebaseAuth.getInstance();
        Databaseref = FirebaseDatabase.getInstance().getReference("User");

        EditText edtId = (EditText) findViewById(R.id.edtLogId);
        EditText edtPw = (EditText) findViewById(R.id.edtLogPw);
        Button btnLogIn = (Button) findViewById(R.id.btnLogIn);
        Button btnSingUp = (Button) findViewById(R.id.btnSignUp);

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String SId = edtId.getText().toString();
                String SPw = edtPw.getText().toString();

                Firebaseauth.signInWithEmailAndPassword(SId, SPw).addOnCompleteListener
                        (MainActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Intent intent = new Intent(getApplicationContext(), view_memo.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        btnSingUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), sign_up.class);
                startActivity(intent);
            }
        });
    }
}