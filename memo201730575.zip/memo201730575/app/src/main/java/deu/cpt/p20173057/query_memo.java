package deu.cpt.p20173057;

import android.app.DownloadManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class query_memo extends AppCompatActivity {
    View dialogview;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.query_memo);

        Intent intent = getIntent();
        int getpos = intent.getIntExtra("pos", 0);
        int pos = getpos + 1;
        String getDate = intent.getStringExtra("date");
        String getMod_Date = intent.getStringExtra("mod_date");
        String getTitle = intent.getStringExtra("title");
        String getDetail = intent.getStringExtra("detail");
        String getId = intent.getStringExtra("id");
        setTitle(getId + "번 메모");

        LinearLayout llModDate = (LinearLayout) findViewById(R.id.llModDate);
        TextView tvDate2 = (TextView) findViewById(R.id.tvDate2);
        TextView tvModDate2 = (TextView) findViewById(R.id.tvModDate2);
        TextView tvTitle2 = (TextView) findViewById(R.id.tvTitle2);
        TextView tvDetail2 = (TextView) findViewById(R.id.tvDetail2);
        Button btnEdit = (Button) findViewById(R.id.btnEdit);
        Button btnRemove = (Button) findViewById(R.id.btnRemove);
        Button btnBack = (Button) findViewById(R.id.btnBack);

        tvDate2.setText(getDate);
        tvTitle2.setText(getTitle);
        tvDetail2.setText(getDetail);
        //최종수정일자가 존재하지 않을 경우
        if(getMod_Date == null){
            //최종수정일자 레이아웃을 사라지게 함
            llModDate.setVisibility(View.GONE);
        }
        //최종수정일자가 존재할 경우
        else{
            tvModDate2.setText(getMod_Date);
        }

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(query_memo.this, edt_memo.class);
                intent.putExtra("Pos", getpos);
                intent.putExtra("Title", getTitle);
                intent.putExtra("Detail", getDetail);
                intent.putExtra("Date", getDate);
                startActivity(intent);
            }
        });

        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogview = (View) View.inflate(query_memo.this, R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(query_memo.this);
                String Message = "이 메모(" + pos + ")번 메모를 삭제하시겠습니까?";
                dlg.setMessage(Message);
                dlg.setView(dialogview);
                dlg.setNegativeButton("취소", null);
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(query_memo.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
                dlg.show();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
